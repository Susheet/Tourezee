import { Component, OnInit, ViewChild } from '@angular/core';
import { StayService } from '../stay.service';

@Component({
  selector: 'app-stay-filters',
  templateUrl: './stay-filters.component.html',
  styleUrls: ['./stay-filters.component.css']
})
export class StayFiltersComponent implements OnInit {
  isChecked : any;

  constructor(private stayService:StayService) { 
    
  }
  
  ngOnInit(): void {
    this.stayService.hotelChecked=this.isChecked
    console.log(this.isChecked)
    console.log(this.stayService.hotelChecked);
  }

}
