import { HttpClient } from '@angular/common/http';
import { ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StayService } from '../stay.service';

@Component({
  selector: 'app-stay-list',
  templateUrl: './stay-list.component.html',
  styleUrls: ['./stay-list.component.css']
})
export class StayListComponent implements OnInit {
   hotels : any
  star:number;
  place:any
  @ViewChild('placeInput',{static:false}) placeInputRef:ElementRef

  constructor(private router:Router,
              private stayService:StayService,
              private http:HttpClient) { }
    

  ngOnInit(): void {
      this.stayService.getHotel().subscribe(
      (hotel:any) => {
        
        this.hotels = hotel;
      }
    )
    }
    onSearch(){
      //this.place=this.placeInputRef.nativeElement.value;
      this.place='Delhi';
      if(this.place==="Singapore"){
        this.stayService.cityName="Singapore";
        this.stayService.countryName=this.place;
      }
      else if(this.place==="India"){
        this.stayService.cityName="Delhi";
        this.stayService.countryName=this.place;
      }
      else if(this.place==="Delhi"){
        this.stayService.cityName=this.place;
        this.stayService.countryName="India";
      }
      else if(this.place==="Thailand"){
        this.stayService.cityName="Bangkok";
        this.stayService.countryName=this.place;
      }
      else if(this.place==="Bangkok"){
        this.stayService.cityName=this.place;
        this.stayService.countryName="Thailand";
      }
      else if(this.place==="Phuket"){
        this.stayService.cityName=this.place;
        this.stayService.countryName="Thailand";
      }
      this.stayService.getByPlace().subscribe((hotel:any)=>{
       this.hotels=hotel;
      })
    }
  getBusinessHotels(){
     this.stayService.getBusiness().subscribe((hotel:any)=>{
       this.hotels=hotel;
     })
  }
  getMedicalHotels(){
    this.stayService.getMedical().subscribe((hotel:any)=>{
      this.hotels=hotel;
    })
  }
  getStudentHotels(){
    this.stayService.getStudent().subscribe((hotel:any)=>{
      this.hotels=hotel;
    })
  }
  getTouristHotels(){
    this.stayService.getTourist().subscribe((hotel:any)=>{
      this.hotels=hotel;
    })
  }

}

