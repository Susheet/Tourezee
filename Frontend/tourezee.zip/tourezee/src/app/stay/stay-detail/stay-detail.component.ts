import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { StayService } from '../stay.service';

@Component({
  selector: 'app-stay-detail',
  templateUrl: './stay-detail.component.html',
  styleUrls: ['./stay-detail.component.css']
})
export class StayDetailComponent implements OnInit {
  @Input() hotel:any
  Arr = Array; 
  num:number
  
  constructor(private stayService:StayService ) { 
  
  }
 
  ngOnInit(): void {
    this.num=+this.hotel.Stars;
  }
  
}
