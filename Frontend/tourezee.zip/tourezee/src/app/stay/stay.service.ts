import { HttpClient } from "@angular/common/http";
import { EventEmitter, Injectable, Output } from "@angular/core";
import { Stay } from "../shared/stay.model";


@Injectable()
export class StayService{
    
    countryName:any
    cityName:any
    hotelChecked:any
    

    hotelSelected=new EventEmitter<any>();
    constructor(private http: HttpClient){
        
    }
    ngOnInit():void{
        
      }
      
    changeStatus(variable1:boolean){
        if(variable1 == true)
        return "Yes";
        else
        return "No";

    }

    getByPlace(){
        return this.http.get(`https://tourezee.herokuapp.com/hotels?country=${this.countryName}&city=${this.cityName}`)
    }  
    getHotel(){
        return this.http.get(`https://tourezee.herokuapp.com/hotels?country=Singapore&city=Singapore`);
    }
    getBusiness(){
        return this.http.get(`https://tourezee.herokuapp.com/hotels/business?country=${this.countryName}&city=${this.cityName}&cabService=No&swimmingPool=No&spa=No&roomService=No&bar=No&gym=No&parking=No&restaurant=No`);
    }
    getMedical(){
        return this.http.get(`https://tourezee.herokuapp.com/hotels/medical?country=${this.countryName}&city=${this.cityName}&swimmingPool=No&spa=No&roomService=No&bar=No&gym=No&babyFriendly=No&parking=No&restaurant=No`);
    }
    getStudent(){
        return this.http.get(`https://tourezee.herokuapp.com/hotels/student?country=${this.countryName}&city=${this.cityName}&cabService=No&swimmingPool=No&houseKeeping=No&spa=No&roomService=No&bar=No&gym=No&restaurant=No`);
    }
    getTourist(){
        return this.http.get(`https://tourezee.herokuapp.com/hotels/tourist?country=${this.countryName}&city=${this.cityName}&cabService=No&swimmingPool=No&houseKeeping=No&spa=No&roomService=No&gym=No&babyFriendly=No&restaurant=No`);
    }

}
