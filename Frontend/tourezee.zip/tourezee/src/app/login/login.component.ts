import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {NgForm} from "@angular/forms";
import { userService } from '../register/user.service.';
// import { UserLogin } from '../shared/userLogin.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router,
    private user:userService,
    private toastr: ToastrService){}  
ngOnInit(): void {
}


onSubmit(f: NgForm){
  const {email,password} = f.form.value;

  //TODO: do your checking here
  this.user.signIn(email,password)
  .then((res) => {
    this.router.navigateByUrl('/');
    this.toastr.success("Sign In Success")
  })
  .catch((err) => {
    console.log(err.message);
    this.toastr.error("Sign In Failed!!")
  })
}

 
  // onLogin(){
  //   //complex logic

  //   this.router.navigate(['/']);
  // }

}
