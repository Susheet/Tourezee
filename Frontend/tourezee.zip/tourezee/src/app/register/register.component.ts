import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../shared/user.model';
import { userService } from './user.service.';
import { ToastrService } from 'ngx-toastr';
import {NgForm} from "@angular/forms";



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @ViewChild('nameInput',{static:false}) nameInputRef:ElementRef
  @ViewChild('emailInput',{static:false}) emailInputRef:ElementRef
  @ViewChild('passwordInput',{static:false}) passwordInputRef:ElementRef
  constructor(private router:Router,
              private user:userService,
              private toastr: ToastrService){}
  ngOnInit(){

  }

 
  onSubmit(f: NgForm){
    const {email,password} = f.form.value;

    //TODO: do your checking here
    this.user.signUp(email,password)
    .then((res) => {
      this.router.navigateByUrl('/');
      this.toastr.success("Sign up Success")
    })
    .catch((err) => {
      console.log(err.message);
      this.toastr.error("Signup Failed!!")
    })
  }


  // onRegister(){
  //   const user=new User(this.nameInputRef.nativeElement.value,
  //     this.emailInputRef.nativeElement.value,
  //     this.passwordInputRef.nativeElement.value);
  //   this.user.addUser(user);
  //   this.router.navigate(['/login']);
  // }
 
}
